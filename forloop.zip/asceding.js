//Q5>findout the ascending order, descending order of given array [1,3,5,6,8,11,4,2,0]
const array =[1,3,5,6,8,11,4,2,0];
array.sort(function(a,b){return (a-b)})
console.log(array);