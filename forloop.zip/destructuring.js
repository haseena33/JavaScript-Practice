//Q3>Write Object destructuring for given object const Person={id:121,name:"harika",age:56}
const Person={
    id:121,
    name:"harika",
    age:56
}
const {id,name,age}=Person;
console.log(name);
console.log(id);
console.log(age);